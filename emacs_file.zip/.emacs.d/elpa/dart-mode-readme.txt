Major mode for editing Dart files.

Provides basic syntax highlighting and indentation. Also provides
formatting via the dartfmt and diff executables.
